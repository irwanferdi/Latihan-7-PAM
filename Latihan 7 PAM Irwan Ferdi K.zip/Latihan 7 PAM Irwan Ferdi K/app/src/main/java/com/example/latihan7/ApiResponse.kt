package com.example.latihan7

data class ApiResponse(
    val data: List<User>
)